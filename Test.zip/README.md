# Desktop-Grabber
 
### No information
```
I wont create any "documentation" for this one. It's a class for Desktop Grabbing. 

Not really complete.

```
